﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace TestApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DynamicSeriesController : ControllerBase
    {
        [HttpGet]  
        [Route ("{m}")]
        public IActionResult Get(int m)
        {
            //int m = 5;
            List<int> dynamicList = new List<int>();
            int noElemAdded = 2;
            
            for(int i=0; i< m; i++)
            {
                int nextElement = 0;
                for (int j=0; j<=2;j++)
                {
                    if (i==0 )
                    { 
                    dynamicList.Add(i+1);
                    }
                }
                int listCount = dynamicList.Count - 1;
                for (int k= 0; k<=2; k++ )
                {
                    
                    nextElement =  nextElement +  dynamicList.ElementAt(listCount );                    
                    listCount = listCount -1 ; 
                }
                dynamicList.Add(nextElement);

            }
            return Ok(dynamicList);

        }
    }
}
